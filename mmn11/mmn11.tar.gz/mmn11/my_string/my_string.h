void displayAnswer(int functionNumber, int functionAnswer, char *firstArgument, char *secondArgument, int thirdArgument, char *strCharAnswer);
int my_strcmp(char *firstArgument, char *secondArgument);
int my_strncmp(char *firstArgument, char *secondArgument, int n);
char *my_strchr(char *firstArgument, int secondArgument);
void OptionsMessage();

#define MAX_STRING 128
