I am a dog.

You are a cat.

We  all  are  animals.

"i think we need help.

Yes we do.

" please.

Hello,
this stone is  years Old.

This is sequence: "" .

..

The end
