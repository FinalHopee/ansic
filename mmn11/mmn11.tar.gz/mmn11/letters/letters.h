#define YES 1
#define NO 0
#define ASCII_SMALL_BIG_LETTER 32
